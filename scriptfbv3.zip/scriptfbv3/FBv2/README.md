# AUTO MBF

# PROSES CRACK LEBIH CEPAT!!

$ pkg update && pkg upgrdae -y

$ pkg install python2 -y

$ pkg install git -y

$ pip2 install requests

$ pip2 install mechanize

$ git clone https://github.com/unikers71/autombf

$ cd autombf

$ python2 mbf.py
