# Dark4

#Pecipta Yoga Wira & Rendy Andhika
$ pkg update
$ pkg upgrade
$ pkg install python2
$ pip2 install requests
$ pip2 install mechanize
$ pkg install git
$ git clone https://github.com/cyber2611/Dark4
$ ls
$ cd Dark4
$ ls
$ python2 Dark4.py
